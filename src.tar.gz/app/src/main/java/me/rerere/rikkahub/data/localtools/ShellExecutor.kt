package me.rerere.rikkahub.data.localtools

import android.content.Context
import java.io.File
import java.io.InputStream
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

/** Shell 执行结果 */
data class ShellResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
    val timedOut: Boolean = false,
) {
    val isSuccess: Boolean get() = exitCode == 0
    val output: String get() = buildString {
        if (stdout.isNotBlank()) append(stdout)
        if (stderr.isNotBlank()) { if (isNotEmpty()) append('\n'); append(stderr) }
    }
}

/** 执行权限模式 */
enum class ShellMode { NORMAL, ROOT }

/**
 * 设备 Shell 执行器：优先 root(su)，否则普通 app 权限。
 *
 * 原生工具链执行走 [executeToolchain]：在 root/shell 域直接 exec app data 目录下的
 * arm64 二进制（targetSdk 37 的 untrusted_app 域因 W^X 无法直接 exec，故必须走 root/Shizuku 通道）。
 */
class ShellExecutor(
    private val context: Context,
) {
    companion object {
        const val HOST_PATH =
            "/sbin:/system/bin:/system/xbin:/product/bin:/apex/com.android.runtime/bin:/apex/com.android.art/bin"
    }

    fun preferredMode(): ShellMode = if (isRootAvailable()) ShellMode.ROOT else ShellMode.NORMAL
    fun hasPrivilege(): Boolean = isRootAvailable() || isShizukuAvailable()

    fun isRootAvailable(): Boolean = runCatching {
        val p = ProcessBuilder("/system/bin/sh", "-c", "su -c id 2>/dev/null").redirectErrorStream(true).start()
        p.outputStream.close()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor(8, TimeUnit.SECONDS) && out.contains("uid=0")
    }.getOrDefault(false)

    /** Shizuku 是否在运行（作为 root 之外的可选通道；本工程实际执行以 root(su) 为主）。 */
    fun isShizukuAvailable(): Boolean = runCatching {
        val p = ProcessBuilder("/system/bin/sh", "-c", "ps -A 2>/dev/null | grep -q 'shizuku_server' || (pidof shizuku_server >/dev/null 2>&1)").start()
        p.waitFor(4, TimeUnit.SECONDS) && p.exitValue() == 0
    }.getOrDefault(false)

    suspend fun execute(
        command: String,
        cwd: String? = null,
        timeoutMillis: Long = 60_000,
        mode: ShellMode = ShellMode.NORMAL,
    ): ShellResult = withContext(Dispatchers.IO) {
        val process = try {
            when (mode) {
                ShellMode.NORMAL -> startNormal(command, cwd)
                ShellMode.ROOT -> startRoot(command, cwd)
            }
        } catch (e: Throwable) {
            return@withContext ShellResult(-1, "", e.message ?: "执行失败")
        }
        awaitProcess(process, timeoutMillis)
    }

    /**
     * 在聚合后的原生工具链环境里执行命令（root 通道直跑 data 目录 arm64 二进制）。
     * PATH/LD_LIBRARY_PATH 指向所有已装扩展的 payload/bin、payload/lib。
     */
    suspend fun executeToolchain(
        command: String,
        cwd: String? = null,
        timeoutMillis: Long = 60_000,
        env: ToolchainEnv,
    ): ShellResult {
        if (!isRootAvailable()) {
            return ShellResult(-1, "", "需要 root 或 Shizuku 权限才能直跑原生工具链（当前不可用）")
        }
        val script = buildString {
            if (!cwd.isNullOrBlank()) {
                append("cd ").append(cwd.shellQuote()).append(" && ")
            }
            append("export PATH=").append(env.path.shellQuote()).append("; ")
            if (env.ldLibraryPath.isNotBlank()) {
                append("export LD_LIBRARY_PATH=").append(env.ldLibraryPath.shellQuote()).append("; ")
            }
            append("export HOME=").append(env.home.shellQuote()).append("; ")
            append("export TMPDIR=").append(env.tmp.shellQuote()).append("; ")
            append("export LANG=en_US.UTF-8; ")
            append(command)
        }
        return withContext(Dispatchers.IO) {
            val process = try {
                Runtime.getRuntime().exec(arrayOf("su", "-c", script))
            } catch (e: Throwable) {
                return@withContext ShellResult(-1, "", e.message ?: "执行失败")
            }
            awaitProcess(process, timeoutMillis)
        }
    }

    private fun startNormal(command: String, cwd: String?): Process {
        val b = ProcessBuilder("/system/bin/sh", "-c", command)
        if (!cwd.isNullOrBlank()) b.directory(File(cwd))
        b.environment()["PATH"] = HOST_PATH
        val p = b.start(); runCatching { p.outputStream.close() }; return p
    }

    private fun startRoot(command: String, cwd: String?): Process {
        val full = buildString {
            if (!cwd.isNullOrBlank()) { append("cd "); append(cwd.shellQuote()); append(" && ") }
            append(command)
        }
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", full))
        runCatching { p.outputStream.close() }; return p
    }

    private suspend fun awaitProcess(process: Process, timeoutMillis: Long): ShellResult {
        val outBuf = StringBuilder(); val errBuf = StringBuilder()
        val outT = daemonReader(process.inputStream, outBuf)
        val errT = daemonReader(process.errorStream, errBuf)
        val finished = try {
            withTimeout(timeoutMillis) { while (process.isAlive) delay(25); true }
        } catch (_: TimeoutCancellationException) { false }
        catch (e: CancellationException) { runCatching { process.destroyForcibly() }; throw e }
        if (!finished) { runCatching { process.destroyForcibly() }; runCatching { process.waitFor(2, TimeUnit.SECONDS) } }
        outT.join(2_000); errT.join(2_000)
        val code = if (finished) runCatching { process.exitValue() }.getOrDefault(-1) else -1
        return ShellResult(code, outBuf.toString(), errBuf.toString(), timedOut = !finished)
    }

    private fun daemonReader(stream: InputStream, buf: StringBuilder): Thread {
        val t = Thread {
            runCatching {
                stream.bufferedReader().use { r ->
                    val c = CharArray(4096)
                    while (true) { val n = r.read(c); if (n < 0) break; synchronized(buf) { buf.append(c, 0, n) } }
                }
            }
        }
        t.isDaemon = true; t.start(); return t
    }

    suspend fun fileExists(path: String): Boolean =
        execute("test -e ${path.shellQuote()} && echo YES || echo NO").stdout.trim() == "YES"

    suspend fun listDirectory(path: String): List<FileEntry> {
        val r = execute("ls -la ${path.shellQuote()} 2>/dev/null | tail -n +2", mode = ShellMode.NORMAL)
        if (!r.isSuccess) return emptyList()
        return r.stdout.lineSequence().filter { it.isNotBlank() }.mapNotNull { parseLsLine(it, path) }.toList()
    }
}

data class FileEntry(val name: String, val isDirectory: Boolean, val sizeBytes: Long, val path: String)

private fun parseLsLine(line: String, basePath: String): FileEntry? {
    if (line.length < 40) return null
    val type = line.firstOrNull() ?: return null
    val name = line.substringAfterLast(" ").trim()
    if (name.isEmpty() || name == "." || name == "..") return null
    val size = line.split(" ").filter { it.isNotBlank() }.getOrNull(4)?.toLongOrNull() ?: 0
    return FileEntry(name, type == 'd', size, if (basePath.endsWith("/")) "$basePath$name" else "$basePath/$name")
}

/** POSIX 单引号转义 */
fun String.shellQuote(): String = "'" + replace("'", "'\\''") + "'"
