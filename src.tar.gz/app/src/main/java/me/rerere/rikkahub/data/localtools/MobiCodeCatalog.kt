package me.rerere.rikkahub.data.localtools

import android.content.Context
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * MobiCode Studio 扩展目录（.mcext 工具链）。
 *
 * 只内置"目录元数据"（extensions.json），不内置任何工具链二进制。
 * 真正的 .mcext 包一律在线下载并由 ExtensionInstaller 解压登记。
 * Android 构建工具链 android.gradle.runtime 被显式排除。
 */

@Serializable
data class CatalogFile(
    val ok: Boolean = true,
    val code: String = "",
    val data: CatalogData = CatalogData(),
)

@Serializable
data class CatalogData(
    val extensions: List<RawExtension> = emptyList(),
)

@Serializable
data class RawExtension(
    @SerialName("extension_id") val extensionId: String,
    val name: String = "",
    val version: String = "",
    val publisher: String = "",
    val description: String = "",
    val category: String = "",
    @SerialName("download_size") val downloadSize: Long = 0,
    @SerialName("download_url") val downloadUrl: String = "",
    @SerialName("archive_sha256") val sha256: String = "",
    @SerialName("repository_url") val repositoryUrl: String = "",
    @SerialName("license_name") val licenseName: String = "",
    @SerialName("minimum_app_version") val minimumAppVersion: Int = 0,
    val languages: List<String> = emptyList(),
    @SerialName("project_templates") val projectTemplates: List<String> = emptyList(),
)

data class ToolchainExtension(
    val id: String,
    val name: String,
    val version: String,
    val publisher: String,
    val description: String,
    val category: String,
    val downloadSize: Long,
    val downloadUrl: String,
    val sha256: String,
    val repositoryUrl: String,
    val licenseName: String,
    val minimumAppVersion: Int,
)

object MobiCodeCatalog {
    const val EXCLUDED_ID = "__include_all__"

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    @Volatile
    private var cached: List<ToolchainExtension>? = null

    fun extensions(context: Context): List<ToolchainExtension> {
        cached?.let { return it }
        val list = runCatching {
            val text = context.assets.open("mobicode_extensions.json").bufferedReader().use { it.readText() }
            val file = json.decodeFromString(CatalogFile.serializer(), text)
            file.data.extensions
                .filter { it.extensionId != EXCLUDED_ID }
                .map { it.toModel() }
        }.getOrElse { emptyList() }
        cached = list
        return list
    }

    fun find(context: Context, id: String): ToolchainExtension? =
        extensions(context).firstOrNull { it.id == id }

    private fun RawExtension.toModel() = ToolchainExtension(
        id = extensionId,
        name = name.ifBlank { extensionId },
        version = version,
        publisher = publisher,
        description = description,
        category = category,
        downloadSize = downloadSize,
        downloadUrl = downloadUrl,
        sha256 = sha256,
        repositoryUrl = repositoryUrl,
        licenseName = licenseName,
        minimumAppVersion = minimumAppVersion,
    )
}
