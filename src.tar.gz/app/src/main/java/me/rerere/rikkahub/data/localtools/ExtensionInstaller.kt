package me.rerere.rikkahub.data.localtools

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.zip.ZipFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class InstalledRecord(
    val id: String,
    val version: String,
    val payloadDir: String,
    val installedAt: Long = 0L,
    val downloadBytes: Long = 0L,
)

@Serializable
data class InstalledManifest(
    val records: List<InstalledRecord> = emptyList(),
)

/**
 * 在线扩展安装器：
 *  下载 .mcext(标准 ZIP) -> sha256 校验 -> 解压 payload/ 到
 *  files/extensions/<id>/<version>/payload -> 记录到 installed.json。
 *
 * 不内置任何扩展二进制，全部在线获取并校验。
 */
class ExtensionInstaller(
    private val context: Context,
    private val shellExecutor: ShellExecutor,
) {
    companion object {
        private const val EXT_DIR = "extensions"
        private const val MANIFEST = "installed.json"
        private const val USER_AGENT = "RikkaHub-MobiCode-Toolchain/1.0"
    }

    private val json = Json { ignoreUnknownKeys = true; prettyPrint = true; isLenient = true }

    private val extRoot: File get() = File(context.filesDir, EXT_DIR)
    private val manifestFile: File get() = File(extRoot, MANIFEST)

    private val _installed = MutableStateFlow<Map<String, InstalledRecord>>(emptyMap())
    val installed: StateFlow<Map<String, InstalledRecord>> = _installed.asStateFlow()

    init {
        _installed.value = loadManifest()
    }

    fun isInstalled(id: String): Boolean = _installed.value.containsKey(id)

    fun payloadDirOf(id: String): String? = _installed.value[id]?.payloadDir

    @Synchronized
    fun refresh() {
        _installed.value = loadManifest()
    }

    private fun loadManifest(): Map<String, InstalledRecord> = runCatching {
        if (!manifestFile.exists()) return emptyMap()
        val data = json.decodeFromString(InstalledManifest.serializer(), manifestFile.readText())
        // 只保留目录仍存在的记录
        data.records.filter { File(it.payloadDir, "bin").exists() || File(it.payloadDir, "lib").exists() }
            .associateBy { it.id }
    }.getOrElse { emptyMap() }

    private fun saveManifest(map: Map<String, InstalledRecord>) {
        runCatching {
            extRoot.mkdirs()
            val tmp = File(extRoot, "$MANIFEST.tmp")
            tmp.writeText(json.encodeToString(InstalledManifest.serializer(), InstalledManifest(map.values.toList())))
            if (manifestFile.exists()) manifestFile.delete()
            tmp.renameTo(manifestFile)
        }
    }

    /**
     * 在线安装一个扩展。
     * @param onProgress (downloadedBytes, totalBytes, percent 0..100)
     */
    suspend fun install(
        entry: ToolchainExtension,
        onProgress: (downloaded: Long, total: Long) -> Unit = { _, _ -> },
    ): Result<InstalledRecord> = withContext(Dispatchers.IO) {
        runCatching {
            require(entry.downloadUrl.isNotBlank()) { "扩展 ${entry.name} 缺少下载地址" }
            extRoot.mkdirs()
            val workDir = File(extRoot, "_tmp_${entry.id}")
            workDir.mkdirs()
            val archive = File(workDir, "archive.mcext")

            // 1) 下载 + 流式 sha256
            val actualSha = downloadAndHash(entry.downloadUrl, archive, onProgress)
            val expected = entry.sha256.lowercase().trim()
            if (expected.isNotBlank() && actualSha.lowercase() != expected) {
                archive.delete(); workDir.deleteRecursively()
                error("sha256 校验失败：期望 $expected，实际 $actualSha")
            }

            // 2) 解压 payload/
            val versionDir = File(extRoot, "${entry.id}/${entry.version}")
            versionDir.deleteRecursively()
            val payloadDir = File(versionDir, "payload")
            payloadDir.mkdirs()
            val count = extractPayload(archive, payloadDir)
            if (count <= 0) {
                versionDir.deleteRecursively(); archive.delete(); workDir.deleteRecursively()
                error("扩展包内未找到 payload/ 内容")
            }

            // 3) 赋可执行权限（经 root 通道；工具链执行为 root/shizuku 域）
            runCatching {
                shellExecutor.execute(
                    "chmod -R 0755 ${payloadDir.absolutePath.shellQuote()}",
                    timeoutMillis = 120_000,
                    mode = ShellMode.ROOT,
                )
            }

            archive.delete(); workDir.deleteRecursively()

            val record = InstalledRecord(
                id = entry.id,
                version = entry.version,
                payloadDir = payloadDir.absolutePath,
                installedAt = System.currentTimeMillis(),
                downloadBytes = entry.downloadSize,
            )
            val map = _installed.value.toMutableMap()
            map[entry.id] = record
            saveManifest(map)
            _installed.value = map
            record
        }
    }

    suspend fun uninstall(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val rec = _installed.value[id]
            // 删除该扩展所有版本目录
            File(extRoot, id).deleteRecursively()
            rec?.payloadDir?.let { File(it).parentFile?.deleteRecursively() }
            val map = _installed.value.toMutableMap()
            map.remove(id)
            saveManifest(map)
            _installed.value = map
        }
    }

    private fun downloadAndHash(
        urlStr: String,
        dest: File,
        onProgress: (Long, Long) -> Unit,
    ): String {
        val url = URL(urlStr)
        var conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 30_000
        conn.readTimeout = 60_000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", USER_AGENT)
        conn.requestMethod = "GET"
        var code = conn.responseCode
        // 处理 3xx（部分实现不自动跟随跨域重定向）
        var redirects = 0
        while (code in 300..399 && redirects < 5) {
            val loc = conn.getHeaderField("Location") ?: break
            conn.disconnect()
            conn = (URL(loc).openConnection() as HttpURLConnection).apply {
                connectTimeout = 30_000; readTimeout = 60_000; instanceFollowRedirects = true
                setRequestProperty("User-Agent", USER_AGENT); requestMethod = "GET"
            }
            code = conn.responseCode
            redirects++
        }
        if (code !in 200..299) {
            conn.disconnect()
            error("下载失败 HTTP $code：$urlStr")
        }
        val total = conn.contentLengthLong.takeIf { it > 0 } ?: -1L
        val md = MessageDigest.getInstance("SHA-256")
        var downloaded = 0L
        conn.inputStream.use { input ->
            dest.outputStream().use { output ->
                val buf = ByteArray(128 * 1024)
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    output.write(buf, 0, n)
                    md.update(buf, 0, n)
                    downloaded += n
                    onProgress(downloaded, total)
                }
            }
        }
        conn.disconnect()
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** 解压 zip 中 payload/ 下的所有条目到 payloadDir，返回解压文件数。 */
    private fun extractPayload(archive: File, payloadDir: File): Int {
        var count = 0
        ZipFile(archive).use { zf ->
            val entries = zf.entries()
            while (entries.hasMoreElements()) {
                val e = entries.nextElement()
                val name = e.name.replace('\\', '/')
                if (!name.startsWith("payload/")) continue
                val rel = name.removePrefix("payload/")
                if (rel.isEmpty()) continue
                // 防目录穿越
                if (rel.contains("..")) continue
                val outFile = File(payloadDir, rel)
                if (e.isDirectory) {
                    outFile.mkdirs(); continue
                }
                outFile.parentFile?.mkdirs()
                zf.getInputStream(e).use { input ->
                    outFile.outputStream().use { output -> input.copyTo(output, 128 * 1024) }
                }
                count++
            }
        }
        return count
    }
}
