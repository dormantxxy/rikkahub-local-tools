package me.rerere.rikkahub.data.ai.tools.local

import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import me.rerere.ai.core.InputSchema
import me.rerere.ai.core.Tool
import me.rerere.ai.ui.UIMessagePart

/** 网页浏览：后台抓取返回正文文本（不做前台 WebView 渲染）。 */
internal fun buildWebFetchTool(): Tool = Tool(
    name = "web_fetch",
    description = "Fetch a web page URL and return its text content (background HTTP GET, no rendering). Params: url(required), max_chars(optional, default 8000).",
    parameters = {
        InputSchema.Obj(
            properties = buildJsonObject {
                put("url", buildJsonObject { put("type", "string"); put("description", "http(s) URL") })
                put("max_chars", buildJsonObject { put("type", "number"); put("description", "Max chars to return (default 8000)") })
            },
            required = listOf("url"),
        )
    },
    execute = {
        val p = it.jsonObject
        val url = p["url"]?.jsonPrimitive?.contentOrNull ?: error("url is required")
        val maxChars = (p["max_chars"]?.jsonPrimitive?.contentOrNull?.toIntOrNull() ?: 8000).coerceIn(200, 60000)
        val result = withContext(Dispatchers.IO) {
            runCatching {
                val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20_000; readTimeout = 30_000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "Mozilla/5.0 (RikkaHub)")
                    instanceFollowRedirects = true
                }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val raw = stream?.bufferedReader()?.use { it.readText() } ?: ""
                val contentType = conn.contentType ?: ""
                conn.disconnect()
                val text = if (contentType.contains("html", true) || raw.trimStart().startsWith("<")) stripHtml(raw) else raw
                Triple(code, contentType, text)
            }
        }
        val payload = result.map { (code, ct, text) ->
            buildJsonObject { put("status", code); put("content_type", ct); put("text", text.take(maxChars)) }
        }.getOrElse { e -> buildJsonObject { put("error", e.message ?: e.javaClass.simpleName) } }
        listOf(UIMessagePart.Text(payload.toString()))
    }
)

private fun stripHtml(html: String): String {
    var s = html.replace(Regex("(?is)<script.*?</script>"), " ")
        .replace(Regex("(?is)<style.*?</style>"), " ")
        .replace(Regex("(?s)<[^>]+>"), " ")
    s = s.replace(Regex("[ \\t\\x0B\\f\\r]+"), " ").replace(Regex("\\n\\s*\\n+"), "\n").trim()
    return s
}
