package me.rerere.rikkahub.data.localtools

import android.content.Context
import java.io.File

/**
 * 聚合后的一体化"原生工具链环境"。
 * 把所有已装扩展的 payload/bin 汇总成 PATH、payload/lib 汇总成 LD_LIBRARY_PATH，
 * 形成一个可直接运行 git/python3/node/gcc/apktool/java 等的环境。
 */
data class ToolchainEnv(
    val path: String,
    val ldLibraryPath: String,
    val home: String,
    val tmp: String,
    val binDirs: List<String>,
    val libDirs: List<String>,
) {
    val isEmpty: Boolean get() = binDirs.isEmpty() && libDirs.isEmpty()
}

object ToolchainEnvironment {
    /** 宿主系统基础 PATH（root/shell 域可用的系统工具）。 */
    const val HOST_PATH =
        "/system/bin:/system/xbin:/system/sbin:/product/bin:/apex/com.android.runtime/bin:/apex/com.android.art/bin"

    fun build(context: Context, installer: ExtensionInstaller): ToolchainEnv {
        val home = File(context.filesDir, "toolchain/home").apply { mkdirs() }
        val tmp = File(context.filesDir, "toolchain/tmp").apply { mkdirs() }
        val records = installer.installed.value.values.sortedBy { it.id }
        val binDirs = records.mapNotNull { rec ->
            File(rec.payloadDir, "bin").takeIf { it.isDirectory }?.absolutePath
        }
        val libDirs = records.mapNotNull { rec ->
            File(rec.payloadDir, "lib").takeIf { it.isDirectory }?.absolutePath
        }
        val path = (binDirs + HOST_PATH).joinToString(":")
        val ld = libDirs.joinToString(":")
        return ToolchainEnv(
            path = path,
            ldLibraryPath = ld,
            home = home.absolutePath,
            tmp = tmp.absolutePath,
            binDirs = binDirs,
            libDirs = libDirs,
        )
    }
}
