package me.rerere.ai.registry

import me.rerere.ai.provider.Modality
import me.rerere.ai.provider.ModelAbility

fun interface ModelData<T> {
    fun getData(modelId: String): T
}

object ModelRegistry {
    private val GPT4O = defineModel {
        tokens("gpt", "4", "o")
        visionInput()
        toolAbility()
    }

    private val GPT_4_1 = defineModel {
        tokens("gpt", "4", "1")
        visionInput()
        toolAbility()
    }

    val OPENAI_O_MODELS = defineModel {
        tokens(tokenRegex("^o$"), tokenRegex("^\\d+$"))
        visionInput()
        toolReasoningAbility()
    }

    private val GPT_OSS = defineModel {
        tokens("gpt", "oss")
        toolReasoningAbility()
    }

    val GPT_5 = defineModel {
        tokens("gpt", "5")
        notTokens("gpt", "5", ".")
        notTokens("gpt", "5", "chat")
        visionInput()
        toolReasoningAbility()
    }

    private val GPT_5_1 = defineModel {
        tokens("gpt", "5", "1")
        visionInput()
        toolReasoningAbility()
    }

    private val GPT_5_2 = defineModel {
        tokens("gpt", "5", "2")
        visionInput()
        toolReasoningAbility()
    }

    private val GPT_5_3 = defineModel {
        tokens("gpt", "5", "3")
        visionInput()
        toolAbility()
    }

    private val GPT_5_4 = defineModel {
        tokens("gpt", "5", "4")
        visionInput()
        toolReasoningAbility()
    }

    private val GPT_5_4_MINI = defineModel {
        tokens("gpt", "5", "4", "mini")
        visionInput()
        toolReasoningAbility()
    }

    private val GPT_5_4_NANO = defineModel {
        tokens("gpt", "5", "4", "nano")
        visionInput()
        toolReasoningAbility()
    }

    private val GPT_5_5 = defineModel {
        tokens("gpt", "5", "5")
        visionInput()
        toolReasoningAbility()
    }

    private val GPT_5_6 = defineModel {
        tokens("gpt", "5", "6")
        visionInput()
        toolReasoningAbility()
    }

    private val GPT_6 = defineModel {
        tokens("gpt", "6")
        visionInput()
        toolReasoningAbility()
    }

    private val GEMINI_20_FLASH = defineModel {
        tokens("gemini", "2", "0", "flash")
        visionInput()
        toolAbility()
    }

    val GEMINI_2_5_FLASH = defineModel {
        tokens("gemini", "2", "5", "flash")
        notTokens("image")
        visionInput()
        toolReasoningAbility()
    }

    val GEMINI_2_5_PRO = defineModel {
        tokens("gemini", "2", "5", "pro")
        visionInput()
        toolReasoningAbility()
    }

    val GEMINI_2_5_IMAGE = defineModel {
        tokens("gemini", "2", "5", "flash", "image")
        visionInput()
        imageOutput()
    }

    val GEMINI_3_PRO_IMAGE = defineModel {
        tokens("gemini", "3", "pro", "image")
        visionInput()
        imageOutput()
    }

    val GEMINI_NANO_BANANA = defineModel {
        tokens("nano", "banana")
        visionInput()
        imageOutput()
    }

    val GEMINI_3_PRO = defineModel {
        tokens("gemini", "3", "pro")
        visionInput()
        toolReasoningAbility()
    }

    val GEMINI_3_FLASH = defineModel {
        tokens("gemini", "3", "flash")
        visionInput()
        toolReasoningAbility()
    }

    val GEMINI_3_1_PRO_PREVIEW = defineModel {
        tokens("gemini", "3", "1", "pro", "preview")
        visionInput()
        toolReasoningAbility()
    }

    val GEMINI_3_1_PRO_PREVIEW_CUSTOMTOOLS = defineModel {
        tokens("gemini", "3", "1", "pro", "preview", "customtools")
        visionInput()
        toolReasoningAbility()
    }

    val GEMINI_3_1_FLASH_IMAGE = defineModel {
        tokens("gemini", "3", "1", "flash", "image")
        visionInput()
        imageOutput()
        reasoningAbility()
    }

    val GEMINI_3_5 = defineModel {
        tokens("gemini", "3", "5")
        visionInput()
        toolReasoningAbility()
    }

    val GEMINI_4 = defineModel {
        tokens("gemini", "4")
        visionInput()
        toolReasoningAbility()
    }

    val GEMINI_FLASH_LATEST = defineModel {
        exact("gemini-flash-latest")
        visionInput()
        toolReasoningAbility()
    }

    val GEMINI_PRO_LATEST = defineModel {
        exact("gemini-pro-latest")
        visionInput()
        toolReasoningAbility()
    }

    val GEMINI_LATEST = defineGroup {
        add(GEMINI_FLASH_LATEST, GEMINI_PRO_LATEST)
    }

    val GEMINI_3_SERIES = defineGroup {
        add(GEMINI_3_PRO, GEMINI_3_FLASH, GEMINI_3_1_PRO_PREVIEW, GEMINI_3_1_PRO_PREVIEW_CUSTOMTOOLS, GEMINI_3_5)
    }

    val GEMINI_SERIES = defineGroup {
        add(GEMINI_20_FLASH, GEMINI_2_5_FLASH, GEMINI_2_5_PRO, GEMINI_3_SERIES, GEMINI_4, GEMINI_LATEST)
    }

    private val CLAUDE_4 = defineModel {
        tokens("claude", "4")
        visionInput()
        toolReasoningAbility()
    }

    val CLAUDE_4_5 = defineModel {
        tokens("claude", "4", "5")
        visionInput()
        toolReasoningAbility()
    }

    private val CLAUDE_SONNET_4_6 = defineModel {
        tokens("claude", "sonnet", "4", "6")
        visionInput()
        toolReasoningAbility()
    }

    private val CLAUDE_OPUS_4_6 = defineModel {
        tokens("claude", "opus", "4", "6")
        visionInput()
        toolReasoningAbility()
    }

    private val CLAUDE_OPUS_4_7 = defineModel {
        tokens("claude", "opus", "4", "7")
        visionInput()
        toolReasoningAbility()
    }

    private val CLAUDE_OPUS_4_8 = defineModel {
        tokens("claude", "opus", "4", "8")
        visionInput()
        toolReasoningAbility()
    }

    private val CLAUDE_SONNET_5 = defineModel {
        tokens("claude", "sonnet", "5")
        notTokens("claude", "sonnet", "4")
        visionInput()
        toolReasoningAbility()
        contextLength(1.m)
    }

    private val CLAUDE_OPUS_5 = defineModel {
        tokens("claude", "opus", "5")
        notTokens("claude", "opus", "4")
        visionInput()
        toolReasoningAbility()
        contextLength(1.m)
    }

    private val CLAUDE_SONNET_5_5 = defineModel {
        tokens("claude", "sonnet", "5", "5")
        notTokens("claude", "sonnet", "4")
        visionInput()
        toolReasoningAbility()
        contextLength(1.m)
    }

    private val CLAUDE_OPUS_5_5 = defineModel {
        tokens("claude", "opus", "5", "5")
        notTokens("claude", "opus", "4")
        visionInput()
        toolReasoningAbility()
        contextLength(1.m)
    }

    val CLAUDE_SERIES = defineGroup {
        add(
            CLAUDE_4,
            CLAUDE_4_5,
            CLAUDE_SONNET_4_6,
            CLAUDE_OPUS_4_6,
            CLAUDE_OPUS_4_7,
            CLAUDE_OPUS_4_8,
            CLAUDE_SONNET_5,
            CLAUDE_OPUS_5,
            CLAUDE_SONNET_5_5,
            CLAUDE_OPUS_5_5
        )
    }

    private val DEEPSEEK_V3_MODEL = defineModel {
        tokens("deepseek", "v", "3")
        toolAbility()
    }

    private val DEEPSEEK_CHAT = defineModel {
        tokens("deepseek", "chat")
        toolAbility()
    }

    private val DEEPSEEK_V3 = defineGroup {
        add(DEEPSEEK_V3_MODEL, DEEPSEEK_CHAT)
    }

    private val DEEPSEEK_R1_MODEL = defineModel {
        tokens("deepseek", "r", "1")
        toolReasoningAbility()
    }

    private val DEEPSEEK_REASONER = defineModel {
        tokens("deepseek", "reasoner")
        toolReasoningAbility()
    }

    private val DEEPSEEK_FLASH = defineModel {
        tokens("deepseek", "flash")
        visionInput()
        toolReasoningAbility()
    }

    private val DEEPSEEK_V4_FLASH = defineModel {
        tokens("deepseek", "v", "4", "flash")
        toolReasoningAbility()
        contextLength(1.m)
    }

    private val DEEPSEEK_V4_FLASH_VISION_EXP = defineModel {
        tokens("deepseek", "v", "4", "flash", "vision", "exp")
        visionInput()
        toolReasoningAbility()
        contextLength(1.m)
    }

    private val DEEPSEEK_V4_1_FLASH = defineModel {
        tokens("deepseek", "v", "4", "1", "flash")
        visionInput()
        toolReasoningAbility()
        contextLength(1.m)
    }

    private val DEEPSEEK_V4_PRO = defineModel {
        tokens("deepseek", "v", "4", "pro")
        toolReasoningAbility()
        contextLength(1.m)
    }

    private val DEEPSEEK_R1 = defineGroup {
        add(DEEPSEEK_R1_MODEL, DEEPSEEK_REASONER)
    }

    private val DEEPSEEK_V3_1 = defineModel {
        tokens("deepseek", "v", "3", "1")
        toolReasoningAbility()
    }

    private val DEEPSEEK_V3_2 = defineModel {
        tokens("deepseek", "v", "3", "2")
        toolReasoningAbility()
    }

    private val QWEN_3 = defineModel {
        tokens("qwen", "3")
        toolReasoningAbility()
    }

    private val QWEN_3_VL = defineModel {
        tokens("qwen", "3", "vl")
        visionInput()
        toolReasoningAbility()
    }

    private val QWEN_3_5 = defineModel {
        tokens("qwen", "3", "5")
        visionInput()
        toolReasoningAbility()
    }

    private val QWEN_3_6 = defineModel {
        tokens("qwen", "3", "6")
        visionInput()
        toolReasoningAbility()
    }

    private val QWEN_3_7 = defineModel {
        tokens("qwen", "3", "7")
        visionInput()
        toolReasoningAbility()
    }

    private val QWEN_3_8 = defineModel {
        tokens("qwen", "3", "8")
        visionInput()
        toolReasoningAbility()
    }

    private val QWEN_3_5_MAX = defineModel {
        tokens("qwen", "3", "5", "max")
        toolReasoningAbility()
    }

    private val QWEN_3_6_MAX = defineModel {
        tokens("qwen", "3", "6", "max")
        toolReasoningAbility()
    }

    private val QWEN_3_7_MAX = defineModel {
        tokens("qwen", "3", "7", "max")
        toolReasoningAbility()
    }

    private val QWEN_3_8_MAX = defineModel {
        tokens("qwen", "3", "8", "max")
        toolReasoningAbility()
    }

    private val DOUBAO_1_6 = defineModel {
        tokens("doubao", "1", "6")
        visionInput()
        toolReasoningAbility()
    }

    private val DOUBAO_1_8 = defineModel {
        tokens("doubao", "1", "8")
        visionInput()
        toolReasoningAbility()
    }

    private val DOUBAO_2_0 = defineModel {
        tokens("doubao", "2", "0")
        visionInput()
        toolReasoningAbility()
    }

    private val DOUBAO_2_1 = defineModel {
        tokens("doubao", "2", "1")
        visionInput()
        toolReasoningAbility()
    }

    private val GROK_4 = defineModel {
        tokens("grok", "4")
        visionInput()
        toolReasoningAbility()
    }

    private val KIMI_K2 = defineModel {
        tokens("kimi", "k", "2")
        toolReasoningAbility()
    }

    val KIMI_K2_5 = defineModel {
        tokens("kimi", "k", "2", "5")
        visionInput()
        toolReasoningAbility()
    }

    val KIMI_K2_6 = defineModel {
        tokens("kimi", "k", "2", "6")
        visionInput()
        toolReasoningAbility()
    }

    val KIMI_K3 = defineModel {
        tokens("kimi", "k", "3")
        visionInput()
        toolReasoningAbility()
    }

    // 兼容不带 kimi 前缀的裸 id "k3"
    val KIMI_K3_ALIAS = defineModel {
        exact("k3")
        visionInput()
        toolReasoningAbility()
    }

    private val STEP_3 = defineModel {
        tokens("step", "3")
        visionInput()
        toolReasoningAbility()
    }

    private val STEP_3_7_FLASH = defineModel {
        tokens("step", "3", "7", "flash")
        visionInput()
        toolReasoningAbility()
    }

    private val STEP_5 = defineModel {
        tokens("step", "5")
        visionInput()
        toolReasoningAbility()
    }

    private val INTERN_S1 = defineModel {
        tokens("intern", "s", "1")
        visionInput()
        toolReasoningAbility()
    }

    private val GLM_4_5 = defineModel {
        tokens("glm", "4", "5")
        toolReasoningAbility()
    }

    private val GLM_4_6 = defineModel {
        tokens("glm", "4", "6")
        toolReasoningAbility()
    }

    private val GLM_4_7 = defineModel {
        tokens("glm", "4", "7")
        toolReasoningAbility()
    }

    private val GLM_5 = defineModel {
        tokens("glm", "5")
        toolReasoningAbility()
    }

    private val GLM_5_1 = defineModel {
        tokens("glm", "5", "1")
        toolReasoningAbility()
    }

    private val GLM_5_2 = defineModel {
        tokens("glm", "5", "2")
        toolReasoningAbility()
    }

    private val GLM_5_3 = defineModel {
        tokens("glm", "5", "3")
        toolReasoningAbility()
    }

    private val GLM_5_3_FLASH = defineModel {
        tokens("glm", "5", "3", "flash")
        visionInput()
        toolReasoningAbility()
    }

    private val MINIMAX_M2 = defineModel {
        tokens("minimax", "m", "2")
        toolReasoningAbility()
    }

    private val MINIMAX_M2_5 = defineModel {
        tokens("minimax", "m", "2", "5")
        toolReasoningAbility()
    }

    private val MINIMAX_M2_7 = defineModel {
        tokens("minimax", "m", "2", "7")
        toolReasoningAbility()
    }

    private val MINIMAX_M3 = defineModel {
        tokens("minimax", "m", "3")
        visionInput()
        toolReasoningAbility()
    }

    private val XIAOMI_MIMO_V2 = defineModel {
        tokens("mimo", "v", "2")
        toolReasoningAbility()
    }

    private val XIAOMI_MIMO_V2_PRO = defineModel {
        tokens("mimo", "v", "2", "pro")
        toolReasoningAbility()
    }

    private val XIAOMI_MIMO_V2_5 = defineModel {
        tokens("mimo", "v", "2", "5")
        visionInput()
        toolReasoningAbility()
    }

    private val XIAOMI_MIMO_V2_5_PRO = defineModel {
        tokens("mimo", "v", "2", "5", "pro")
        toolReasoningAbility()
    }

    private val XIAOMI_MIMO_V2_6 = defineModel {
        tokens("mimo", "v", "2", "6")
        visionInput()
        toolReasoningAbility()
    }

    private val XIAOMI_MIMO_V3 = defineModel {
        tokens("mimo", "v", "3")
        visionInput()
        toolReasoningAbility()
    }

    private val XIAOMI_MIMO_V3_PRO = defineModel {
        tokens("mimo", "v", "3", "pro")
        visionInput()
        toolReasoningAbility()
    }

    private val HY3 = defineModel {
        tokens("hy", "3")
        toolReasoningAbility()
    }

    private val HY4 = defineModel {
        tokens("hy", "4")
        toolReasoningAbility()
    }

    private val LONGCAT_2 = defineModel {
        tokens("longcat", "2", "0")
        toolReasoningAbility()
    }

    private val MUSE_SPARK = defineModel {
        tokens("muse", "spark")
        visionInput()
        toolReasoningAbility()
    }

    private val MUSE_GLIMMER = defineModel {
        tokens("muse", "glimmer")
        visionInput()
        toolReasoningAbility()
    }

    val QWEN_MT = defineModel {
        tokens("qwen", "mt")
    }

    private val ALL_MODELS = listOf(
        GPT4O,
        GPT_4_1,
        OPENAI_O_MODELS,
        GPT_OSS,
        GPT_5,
        GPT_5_1,
        GPT_5_2,
        GPT_5_3,
        GPT_5_4,
        GPT_5_4_MINI,
        GPT_5_4_NANO,
        GPT_5_5,
        GPT_5_6,
        GPT_6,
        GEMINI_20_FLASH,
        GEMINI_2_5_FLASH,
        GEMINI_2_5_PRO,
        GEMINI_2_5_IMAGE,
        GEMINI_3_PRO_IMAGE,
        GEMINI_NANO_BANANA,
        GEMINI_3_PRO,
        GEMINI_3_FLASH,
        GEMINI_3_1_PRO_PREVIEW,
        GEMINI_3_1_PRO_PREVIEW_CUSTOMTOOLS,
        GEMINI_3_1_FLASH_IMAGE,
        GEMINI_3_5,
        GEMINI_4,
        GEMINI_FLASH_LATEST,
        GEMINI_PRO_LATEST,
        CLAUDE_4,
        CLAUDE_4_5,
        CLAUDE_SONNET_4_6,
        CLAUDE_OPUS_4_6,
        CLAUDE_OPUS_4_7,
        CLAUDE_OPUS_4_8,
        CLAUDE_SONNET_5,
        CLAUDE_OPUS_5,
        CLAUDE_SONNET_5_5,
        CLAUDE_OPUS_5_5,
        DEEPSEEK_V3_MODEL,
        DEEPSEEK_CHAT,
        DEEPSEEK_R1_MODEL,
        DEEPSEEK_REASONER,
        DEEPSEEK_FLASH,
        DEEPSEEK_V4_FLASH,
        DEEPSEEK_V4_FLASH_VISION_EXP,
        DEEPSEEK_V4_1_FLASH,
        DEEPSEEK_V4_PRO,
        DEEPSEEK_V3_1,
        DEEPSEEK_V3_2,
        QWEN_3,
        QWEN_3_VL,
        QWEN_3_5,
        QWEN_3_6,
        QWEN_3_7,
        QWEN_3_8,
        QWEN_3_5_MAX,
        QWEN_3_6_MAX,
        QWEN_3_7_MAX,
        QWEN_3_8_MAX,
        DOUBAO_1_6,
        DOUBAO_1_8,
        DOUBAO_2_0,
        DOUBAO_2_1,
        GROK_4,
        KIMI_K2,
        KIMI_K2_5,
        KIMI_K2_6,
        KIMI_K3,
        KIMI_K3_ALIAS,
        STEP_3,
        STEP_3_7_FLASH,
        STEP_5,
        INTERN_S1,
        GLM_4_5,
        GLM_4_6,
        GLM_4_7,
        GLM_5,
        GLM_5_1,
        GLM_5_2,
        GLM_5_3,
        GLM_5_3_FLASH,
        MINIMAX_M2,
        MINIMAX_M2_5,
        MINIMAX_M2_7,
        MINIMAX_M3,
        XIAOMI_MIMO_V2,
        XIAOMI_MIMO_V2_PRO,
        XIAOMI_MIMO_V2_5,
        XIAOMI_MIMO_V2_5_PRO,
        XIAOMI_MIMO_V2_6,
        XIAOMI_MIMO_V3,
        XIAOMI_MIMO_V3_PRO,
        HY3,
        HY4,
        LONGCAT_2,
        MUSE_SPARK,
        MUSE_GLIMMER,
        QWEN_MT
    )

    @Volatile
    private var catalog: ModelsDevCatalog? = null

    /** 安装 models.dev 数据：查得到的模型以它为准，查不到的再走上面的 token 规则 */
    fun installCatalog(catalog: ModelsDevCatalog?) {
        this.catalog = catalog
    }

    val MODEL_INPUT_MODALITIES = ModelData { modelId ->
        val info = catalog?.find(modelId)
        if (info != null) {
            sortModalities(info.inputModalities)
        } else {
            resolveModalities(modelId) { it.inputModalities }
        }
    }

    val MODEL_OUTPUT_MODALITIES = ModelData { modelId ->
        val info = catalog?.find(modelId)
        if (info != null) {
            sortModalities(info.outputModalities)
        } else {
            resolveModalities(modelId) { it.outputModalities }
        }
    }

    val MODEL_ABILITIES = ModelData { modelId ->
        val abilities = catalog?.find(modelId)?.abilities
            ?: resolveModels(modelId)
                .flatMap { it.abilities }
                .toSet()
        buildList {
            if (ModelAbility.TOOL in abilities) add(ModelAbility.TOOL)
            if (ModelAbility.REASONING in abilities) add(ModelAbility.REASONING)
        }
    }

    val MODEL_CONTEXT_LENGTH = ModelData { modelId ->
        catalog?.find(modelId)?.contextLength
            ?: resolveModels(modelId).firstNotNullOfOrNull { it.contextLength }
    }

    private fun resolveModels(modelId: String): List<ModelDefinition> {
        val tokens = tokenize(modelId)
        var bestScore: Int? = null
        val matches = mutableListOf<ModelDefinition>()
        for (model in ALL_MODELS) {
            val score = model.matchScore(modelId, tokens) ?: continue
            when {
                bestScore == null || score > bestScore -> {
                    bestScore = score
                    matches.clear()
                    matches.add(model)
                }

                score == bestScore -> matches.add(model)
            }
        }
        return matches
    }

    private fun resolveModalities(
        modelId: String,
        selector: (ModelDefinition) -> Set<Modality>
    ): List<Modality> {
        val modalities = resolveModels(modelId)
            .flatMap { selector(it) }
            .toSet()
        return sortModalities(modalities)
    }

    private fun sortModalities(modalities: Set<Modality>): List<Modality> {
        return if (modalities.isEmpty()) {
            listOf(Modality.TEXT)
        } else {
            listOf(Modality.TEXT, Modality.IMAGE).filter { it in modalities }
        }
    }

    private fun ModelDefinitionBuilder.visionInput() {
        input(Modality.TEXT, Modality.IMAGE)
    }

    private fun ModelDefinitionBuilder.imageOutput() {
        output(Modality.TEXT, Modality.IMAGE)
    }

    private fun ModelDefinitionBuilder.toolAbility() {
        ability(ModelAbility.TOOL)
    }

    private fun ModelDefinitionBuilder.reasoningAbility() {
        ability(ModelAbility.REASONING)
    }

    private fun ModelDefinitionBuilder.toolReasoningAbility() {
        ability(ModelAbility.TOOL, ModelAbility.REASONING)
    }

    private val Int.k: Int get() = this * 1_000
    private val Int.m: Int get() = this * 1_000_000
}
