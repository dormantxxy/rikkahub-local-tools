package me.rerere.ai.ui

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.decodeFromJsonElement
import kotlinx.serialization.json.encodeToJsonElement
import kotlinx.serialization.json.jsonObject
import me.rerere.ai.util.json

/**
 * [UIMessagePart.metadata] 的类型安全 schema
 *
 * metadata 在序列化层仍然是 [JsonObject], 这里只是为读写提供编译期类型:
 * - 读: `part.metadataAs<ClaudeReasoningMetadata>()?.signature`
 * - 写: `part.metadata = ClaudeReasoningMetadata(signature = ...).toMetadata()`
 *
 * 所有字段必须可空且 key 与历史数据保持一致(必要时用 [SerialName]),
 * 否则旧会话中持久化的 metadata 将无法解析
 */
sealed interface PartMetadata

/**
 * Claude thinking block 的元数据, 回传时需要携带 signature
 */
@Serializable
data class ClaudeReasoningMetadata(
    val signature: String? = null,
) : PartMetadata

/**
 * OpenAI Responses API reasoning item 的元数据, 回传时需要携带 id 和 encrypted_content
 */
@Serializable
data class OpenAIReasoningMetadata(
    @SerialName("reasoning_id")
    val reasoningId: String? = null,
    @SerialName("encrypted_content")
    val encryptedContent: String? = null,
) : PartMetadata

/**
 * 服务端工具原始块所属的 wire protocol，与实际提供商品牌无关。
 */
@Serializable
enum class ServerToolProtocol {
    @SerialName("openai_responses")
    OPENAI_RESPONSES,

    @SerialName("anthropic_messages")
    ANTHROPIC_MESSAGES,

    @SerialName("google_generate_content")
    GOOGLE_GENERATE_CONTENT,

    @SerialName("google_interactions")
    GOOGLE_INTERACTIONS,
}

/**
 * Provider 服务端工具的原始协议块。
 *
 * 通用字段保存在 [UIMessagePart.ServerTool] 自身；这里额外保留 Provider 原始调用/结果，供多轮请求
 * 原样回传。OpenAI Responses API 通常只使用 [call]，Claude 则分别使用 [call] 和 [result]。
 */
@Serializable
data class ServerToolMetadata(
    @SerialName("server_tool_protocol")
    val protocol: ServerToolProtocol? = null,
    @SerialName("server_tool_call")
    val call: JsonObject? = null,
    @SerialName("server_tool_call_index")
    val callIndex: Int? = null,
    @SerialName("server_tool_result")
    val result: JsonObject? = null,
    @SerialName("server_tool_result_index")
    val resultIndex: Int? = null,
) : PartMetadata

/**
 * OpenRouter Chat Completions 的结构化 reasoning_details，工具调用续轮时需要原样回传。
 */
@Serializable
data class OpenRouterReasoningMetadata(
    @SerialName("openrouter_reasoning_details")
    val reasoningDetails: JsonArray? = null,
) : PartMetadata

/**
 * Google Gemini 部件的 thoughtSignature，回传时需要携带
 */
@Serializable
data class GoogleThoughtMetadata(
    val thoughtSignature: String? = null,
) : PartMetadata

/**
 * Google Interactions API 的 thought / function_call step 签名，无状态多轮时需要原样回传。
 *
 * 与 [GoogleThoughtMetadata] 使用不同的 key，避免在 generateContent 与 Interactions 之间切换时
 * 把一种协议的签名发给另一种协议。
 */
@Serializable
data class GoogleInteractionsMetadata(
    @SerialName("interactions_signature")
    val signature: String? = null,
) : PartMetadata

/**
 * 文件编辑类工具(如 workspace_edit_file)输出部件的元数据,
 * 携带 unified diff 文本供 UI 渲染 diff view, 不会发送给 API
 */
@Serializable
data class DiffMetadata(
    val diff: String? = null,
) : PartMetadata

/**
 * 将 metadata 解析为类型化的 [PartMetadata], 解析失败或 metadata 为 null 时返回 null
 *
 * 由于 json 配置了 ignoreUnknownKeys, 不同 provider 的 metadata 互不干扰
 * (例如切换 provider 后, OpenAI 写入的 reasoning 元数据不会影响 Claude 的解析)
 */
inline fun <reified T : PartMetadata> UIMessagePart.metadataAs(): T? = metadata?.let {
    runCatching { json.decodeFromJsonElement<T>(it) }.getOrNull()
}

/**
 * 将类型化的 [PartMetadata] 编码为 metadata [JsonObject]
 *
 * 由于 json 配置了 explicitNulls = false, 值为 null 的字段不会写入
 */
inline fun <reified T : PartMetadata> T.toMetadata(): JsonObject =
    json.encodeToJsonElement(this).jsonObject
